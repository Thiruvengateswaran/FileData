﻿using System.Configuration;
using ThirdPartyTools;
namespace FileData
{

    public static class Program
    {
        public static void Main(string[] args)
        {
            //Getting Key,Values from App.Config
            var appSettings = ConfigurationManager.AppSettings;
            foreach (var key in appSettings.AllKeys)
            {
               if(args[0] == appSettings[key] && key.Contains("VersionKey"))
                {
                    GetVersion(args[1]);
                    break;
                }
                else if(args[0] == appSettings[key] && key.Contains("SizeKey"))
                {
                    GetSize(args[1]);
                    break;
                }
            }
            System.Console.ReadLine();
        }

        public static void GetVersion(string filename)
        {
            FileDetails fd = new FileDetails();
            System.Console.WriteLine(fd.Version(filename));
        }

        public static void GetSize(string filename)
        {
            FileDetails fd = new FileDetails();
            System.Console.WriteLine(fd.Size(filename));
        }
    }
}
