﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ThirdPartyTools;
using FileData;

namespace FileDataUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestFileDetailVersion()
        {
            //Arrange - Initialize the objects and sets the value
            FileDetails fd = new FileDetails();

            //Act - Invoke the method for test and use the arranged parameter
            bool checkNotNull;
            string str = fd.Version("C:/ test.txt");
            if (str!=null)
            {
                checkNotNull = true;
            }
            else
            {
                checkNotNull = false;
            }

            //Assert - Verifies the results as expected
            Assert.IsTrue(checkNotNull, "Not Null value");
        }
        [TestMethod]
        public void TestFileDetailsize()
        {
            //Arrange - Initialize the objects and sets the value
            FileDetails fd = new FileDetails();
            int fileSize =0;
            //Act - Invoke the method for test and use the arranged parameter
            bool checkInteger =Int32.TryParse(fd.Size("C:/test.txt").ToString(),out fileSize);
            //Assert - Verifies the results as expected
            Assert.IsTrue(checkInteger, "Its an Integer");
            
        }
    }
}
